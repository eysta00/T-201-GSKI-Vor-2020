
class ArrayDeque():
    pass