
class LinkedList():
    pass