from my_array_deque import ArrayDeque
from my_linked_list import LinkedList

class Stack:
    pass