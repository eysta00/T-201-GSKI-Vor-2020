
class Node:
    pass

class DLL:
    pass
